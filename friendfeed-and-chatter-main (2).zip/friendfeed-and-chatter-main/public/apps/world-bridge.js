(() => {
  const openWorld = () => window.parent.postMessage({ type: "lahza:open-world" }, window.location.origin);
  document.addEventListener("click", (event) => {
    const target = event.target instanceof Element ? event.target : null;
    if (!target?.closest('[data-lz-power="enter"], #lz23-launch, [data-lahza-world]')) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    openWorld();
  }, true);
  window.addEventListener("lahza:open-world", openWorld);
  const launch = document.createElement("button");
  launch.type = "button";
  launch.className = "ib";
  launch.dataset.lahzaWorld = "true";
  launch.setAttribute("aria-label", "ادخل العالم");
  launch.title = "ادخل العالم";
  launch.textContent = "🌐";
  const header = document.querySelector("#home header");
  header?.appendChild(launch);
})();