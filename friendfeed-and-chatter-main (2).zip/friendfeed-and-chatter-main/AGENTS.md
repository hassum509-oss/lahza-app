<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep the uploaded standalone Lahza shell isolated in a same-origin iframe; its global scripts must not run in React's document.
- World entry messages must match the shell iframe's origin and window; render the existing WorldView over the mounted shell so returning preserves its state.
- World games use the shared MiniGames panel and browser-safe mini-game rules; keep round completion and local rewards in that panel so each finished round is recorded once.
