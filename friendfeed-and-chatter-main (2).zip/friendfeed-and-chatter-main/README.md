# Lahza Social World

Build a polished, responsive Arabic-first social virtual-world web app named “لحظة | LAHZA SOCIAL”. This is a real interactive app prototype, not a static mockup. Visual direction: premium dark midnight city plaza with luminous violet/purple neon, crystal monument, futuristic social hub, glowing paths, shops, games, “عالمي” portal, friends list, chat, profile/level/XP, wallet balance mock UI, daily missions and bottom/right action controls. Use Arabic RTL by default with optional English labels where appropriate. Mobile-first landscape gameplay: when user enters the world, show a full-screen immersive landscape-oriented play view, request fullscreen/orientation lock when supported, and gracefully show an instruction if browser blocks rotation. Keep normal app home separate; the 3D world is accessed from “عالمي”, not shown on app launch. Create an actual interactive 3D scene using Three.js or React Three Fiber if feasible: plaza ground, glowing central crystal, surrounding futuristic buildings/portals, decorative trees/lamps, NPC avatars, ambient particles and lighting. If true 3D assets are too heavy, make a lightweight performant scene with geometry and fallbacks; do not use a single static background image as the world. Controls: touch joystick on bottom-left, jump/run/emote buttons on bottom-right, top profile/status, friend/chat/notifications, and compact chat composer. Implement touch + keyboard controls, player movement, camera follow/drag rotation, jump, run, emote buttons, NPC proximity greetings, simple interactable locations (shop, games, friends portal), and a working responsive HUD. Provide accessible touch targets, safe areas, reduced-motion support, low/medium/high graphics quality selector, and performance-conscious mobile rendering. Keep initial release self-contained with mock/local state where backend isn’t configured; do not claim real multiplayer or wallet transactions. Add clear separation for future backend integration. Ensure TypeScript compiles, fix errors, and return a preview URL.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/045d53ea-ba96-40b2-a3ac-7b3ee03459dc).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
