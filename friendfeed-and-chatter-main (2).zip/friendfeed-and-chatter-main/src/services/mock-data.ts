// Local mock data. Replace with real backend calls via src/services/backend.ts.
export interface ChatMsg { id: string; from: string; text: string; me?: boolean }

export const mockProfile = { name: "نور", handle: "@noor", level: 7, xp: 340, coins: 1250, gems: 48, avatarColor: "#b46cff" };

export const mockFriends = [
  { id: "f1", name: "ليان", online: true, status: "في الساحة" },
  { id: "f2", name: "سالم", online: true, status: "يلعب سباق النجوم" },
  { id: "f3", name: "ريم", online: false, status: "آخر ظهور منذ ساعة" },
  { id: "f4", name: "خالد", online: false, status: "آخر ظهور أمس" },
];

export const mockMissions = [
  { id: "m1", title: "رحّب بثلاثة سكان", progress: 0, goal: 3, xp: 50 },
  { id: "m2", title: "زُر المتجر", progress: 0, goal: 1, xp: 30 },
  { id: "m3", title: "اقفز ١٠ مرات", progress: 0, goal: 10, xp: 20 },
];

export const mockChat: ChatMsg[] = [
  { id: "c1", from: "ليان", text: "مساء النور! 🌙" },
  { id: "c2", from: "سالم", text: "مين جاي يلعب؟" },
];

export type Rarity = "common" | "rare" | "legendary";
export const RARITY_LABELS: Record<Rarity, string> = { common: "عادي", rare: "نادر", legendary: "أسطوري" };

export interface ShopItem { id: string; name: string; price: number; rarity: Rarity; emoji: string }

export const shopItems: ShopItem[] = [
  { id: "s1", name: "هالة بنفسجية", price: 300, rarity: "common", emoji: "😇" },
  { id: "s2", name: "أجنحة نيون", price: 800, rarity: "rare", emoji: "🪽" },
  { id: "s3", name: "قبعة القمر", price: 150, rarity: "common", emoji: "🌙" },
  { id: "s4", name: "تاج البلورة", price: 2000, rarity: "legendary", emoji: "👑" },
  { id: "s5", name: "وشاح السديم", price: 1200, rarity: "rare", emoji: "🧣" },
  { id: "s6", name: "حذاء البرق", price: 450, rarity: "common", emoji: "⚡" },
  { id: "s7", name: "عصا النجوم", price: 3500, rarity: "legendary", emoji: "✨" },
  { id: "s8", name: "نظارة المجرّة", price: 600, rarity: "rare", emoji: "🕶️" },
];

export const games = [
  { id: "g1", name: "سباق النجوم", en: "Star Race", emoji: "⭐", desc: "اجمع أكبر عدد من النجوم خلال 30 ثانية" },
  { id: "g2", name: "تحدي البلورة", en: "Crystal Quiz", emoji: "🔮", desc: "أجب على أسئلة ثقافية سريعة" },
  { id: "g3", name: "قفز المنصات", en: "Platform Hop", emoji: "🕹️", desc: "اختبر سرعة رد فعلك بالنقر المتتابع" },
];

export interface Challenge { id: string; title: string; period: "يومي" | "أسبوعي"; goal: number; rewardXp: number; rewardCoins: number }

export const challenges: Challenge[] = [
  { id: "ch1", title: "اجمع 15 نجمة في سباق النجوم", period: "يومي", goal: 15, rewardXp: 40, rewardCoins: 100 },
  { id: "ch2", title: "أجب على 5 أسئلة صحيحة في تحدي البلورة", period: "يومي", goal: 5, rewardXp: 50, rewardCoins: 120 },
  { id: "ch3", title: "العب 10 جولات هذا الأسبوع", period: "أسبوعي", goal: 10, rewardXp: 150, rewardCoins: 400 },
];
