// Backend integration seam. All app data flows through this interface.
// Today: local mock implementation only — no real multiplayer, accounts or payments.
// Future: swap `backend` for an implementation backed by Lovable Cloud.
import { mockFriends, mockProfile, type ChatMsg } from "./mock-data";

export interface Backend {
  getProfile(): Promise<typeof mockProfile>;
  getFriends(): Promise<typeof mockFriends>;
  sendChat(text: string): Promise<ChatMsg>;
  /** Mock purchase: deducts local coins only. Not a real transaction. */
  purchase(itemId: string, price: number, balance: number): Promise<{ ok: boolean; balance: number }>;
}

export const backend: Backend = {
  async getProfile() { return mockProfile; },
  async getFriends() { return mockFriends; },
  async sendChat(text) { return { id: String(Date.now()), from: "أنا", text, me: true }; },
  async purchase(_id, price, balance) {
    return balance >= price ? { ok: true, balance: balance - price } : { ok: false, balance };
  },
};
