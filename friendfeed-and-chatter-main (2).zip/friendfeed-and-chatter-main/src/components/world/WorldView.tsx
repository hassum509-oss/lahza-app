import { Canvas } from "@react-three/fiber";
import { Suspense, useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { MiniGames } from "@/components/games/MiniGames";
import { Scene } from "./Scene";
import { input, setState, useGame, showToast, addXp, type Quality } from "@/lib/game-store";
import { backend } from "@/services/backend";
import { shopItems } from "@/services/mock-data";

function Joystick() {
  const base = useRef<HTMLDivElement>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const id = useRef<number | null>(null);
  const move = (e: React.PointerEvent) => {
    if (id.current !== e.pointerId || !base.current) return;
    const r = base.current.getBoundingClientRect();
    let dx = e.clientX - (r.left + r.width / 2), dy = e.clientY - (r.top + r.height / 2);
    const max = r.width / 2, d = Math.hypot(dx, dy);
    if (d > max) { dx *= max / d; dy *= max / d; }
    setKnob({ x: dx, y: dy });
    input.x = dx / max; input.y = -dy / max;
  };
  const end = () => { id.current = null; setKnob({ x: 0, y: 0 }); input.x = 0; input.y = 0; };
  return (
    <div
      ref={base}
      aria-label="عصا التحكم"
      className="glass pointer-events-auto relative size-32 touch-none rounded-full"
      onPointerDown={(e) => { id.current = e.pointerId; (e.target as Element).setPointerCapture(e.pointerId); move(e); }}
      onPointerMove={move}
      onPointerUp={end}
      onPointerCancel={end}
    >
      <div className="neon-bg neon-shadow absolute left-1/2 top-1/2 size-14 rounded-full" style={{ transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }} />
    </div>
  );
}

function RoundBtn({ label, icon, onDown, onUp, big }: { label: string; icon: string; onDown: () => void; onUp?: () => void; big?: boolean }) {
  return (
    <button
      aria-label={label}
      className={`glass pointer-events-auto grid touch-none select-none place-items-center rounded-full active:neon-bg ${big ? "size-20 text-3xl" : "size-14 text-xl"}`}
      onPointerDown={(e) => { e.preventDefault(); onDown(); }}
      onPointerUp={onUp}
      onPointerLeave={onUp}
    >
      <span>{icon}</span>
      <span className="sr-only">{label}</span>
    </button>
  );
}

function Panel() {
  const panel = useGame((s) => s.panel);
  const profile = useGame((s) => s.profile);
  const friends = useGame((s) => s.friends);
  const missions = useGame((s) => s.missions);
  const quality = useGame((s) => s.quality);
  if (!panel || panel === "chat") return null;
  const close = () => setState({ panel: null });
  const titles: Record<string, string> = { shop: "المتجر · Shop", games: "الألعاب · Games", friends: "الأصدقاء · Friends", missions: "المهام اليومية", settings: "الإعدادات · Settings", notifications: "الإشعارات" };
  return (
    <div className="pointer-events-auto absolute inset-0 z-30 grid place-items-center bg-background/60 p-4" onClick={close}>
      <div className="glass max-h-[85%] w-full max-w-md overflow-y-auto rounded-lg p-4" onClick={(e) => e.stopPropagation()} onKeyDown={(e) => e.stopPropagation()} onKeyUp={(e) => e.stopPropagation()} role="dialog" aria-modal="true" aria-label={titles[panel]}>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-display text-2xl">{titles[panel]}</h2>
          <Button variant="secondary" size="icon" aria-label="إغلاق" className="size-11 rounded-full" onClick={close}>✕</Button>
        </div>
        {panel === "shop" && (
          <ul className="space-y-2">
            <p className="text-xs text-muted-foreground">رصيد تجريبي فقط — لا معاملات حقيقية.</p>
            {shopItems.map((it) => (
              <li key={it.id} className="flex items-center justify-between rounded-xl bg-muted p-3">
                <span>{it.name}</span>
                <button className="neon-bg min-h-11 rounded-full px-4 text-sm text-primary-foreground" onClick={async () => {
                  const r = await backend.purchase(it.id, it.price, profile.coins);
                  if (r.ok) { setState((s) => ({ profile: { ...s.profile, coins: r.balance }, missions: s.missions.map((m) => m.id === "m2" ? { ...m, progress: 1 } : m) })); showToast(`اشتريت ${it.name}!`); addXp(15); }
                  else showToast("الرصيد غير كافٍ");
                }}>🪙 {it.price}</button>
              </li>
            ))}
          </ul>
        )}
        {panel === "games" && <MiniGames />}
        {panel === "friends" && (
          <ul className="space-y-2">{friends.map((f) => (
            <li key={f.id} className="flex items-center gap-3 rounded-xl bg-muted p-3 text-sm">
              <span className={`size-2.5 rounded-full ${f.online ? "bg-mint" : "bg-muted-foreground"}`} />{f.name}<span className="text-xs text-muted-foreground">{f.status}</span>
            </li>
          ))}</ul>
        )}
        {panel === "missions" && (
          <ul className="space-y-2">{missions.map((m) => (
            <li key={m.id} className="rounded-xl bg-muted p-3 text-sm">
              <div className="flex justify-between"><span>{m.title}</span><span>{m.progress}/{m.goal}</span></div>
              <div className="mt-2 h-1.5 rounded-full bg-background"><div className="neon-bg h-full rounded-full" style={{ width: `${(m.progress / m.goal) * 100}%` }} /></div>
            </li>
          ))}</ul>
        )}
        {panel === "notifications" && <p className="text-sm text-muted-foreground">ليان أرسلت لك طلب صداقة · سالم دعاك للعب</p>}
        {panel === "settings" && (
          <div>
            <p className="mb-2 text-sm">جودة الرسوميات · Graphics</p>
            <div className="flex gap-2">{(["low", "medium", "high"] as Quality[]).map((q) => (
              <button key={q} aria-pressed={quality === q} className={`min-h-11 flex-1 rounded-full text-sm ${quality === q ? "neon-bg text-primary-foreground" : "bg-muted"}`} onClick={() => setState({ quality: q })}>
                {q === "low" ? "منخفضة" : q === "medium" ? "متوسطة" : "عالية"}
              </button>
            ))}</div>
          </div>
        )}
      </div>
    </div>
  );
}

function ChatBox() {
  const chat = useGame((s) => s.chat);
  const open = useGame((s) => s.panel === "chat");
  const [text, setText] = useState("");
  if (!open) return null;
  return (
    <div className="glass pointer-events-auto absolute right-3 top-20 z-20 flex w-72 max-w-[45vw] flex-col rounded-2xl p-2">
      <div className="max-h-36 space-y-1 overflow-y-auto text-sm">
        {chat.slice(-8).map((m) => <p key={m.id}><b className={m.me ? "text-accent" : "text-mint"}>{m.from}:</b> {m.text}</p>)}
      </div>
      <form className="mt-2 flex gap-1" onSubmit={async (e) => { e.preventDefault(); if (!text.trim()) return; const m = await backend.sendChat(text.trim()); setState((s) => ({ chat: [...s.chat, m] })); setText(""); }}>
        <input value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.stopPropagation()} placeholder="اكتب رسالة…" aria-label="رسالة" className="min-h-10 flex-1 rounded-full bg-muted px-3 text-sm outline-none focus:ring-2 focus:ring-ring" />
        <button className="neon-bg min-h-10 rounded-full px-3 text-sm text-primary-foreground">إرسال</button>
      </form>
    </div>
  );
}

export function WorldView({ onExit }: { onExit?: () => void } = {}) {
  const quality = useGame((s) => s.quality);
  const profile = useGame((s) => s.profile);
  const nearby = useGame((s) => s.nearby);
  const toast = useGame((s) => s.toast);
  const [portrait, setPortrait] = useState(false);
  const [entered, setEntered] = useState(Boolean(onExit));
  const drag = useRef<{ id: number; x: number } | null>(null);

  useEffect(() => {
    const check = () => setPortrait(window.innerHeight > window.innerWidth && window.innerWidth < 900);
    check(); window.addEventListener("resize", check);
    const keys = new Set<string>();
    const sync = () => {
      input.x = (keys.has("KeyD") || keys.has("ArrowRight") ? 1 : 0) - (keys.has("KeyA") || keys.has("ArrowLeft") ? 1 : 0);
      input.y = (keys.has("KeyW") || keys.has("ArrowUp") ? 1 : 0) - (keys.has("KeyS") || keys.has("ArrowDown") ? 1 : 0);
      input.run = keys.has("ShiftLeft") || keys.has("ShiftRight");
    };
    const down = (e: KeyboardEvent) => { if (e.target instanceof Element && e.target.closest('[role="dialog"], input, textarea, button')) return; if (e.code === "Space") { input.jump = true; e.preventDefault(); } if (e.code === "KeyE") input.emote = true; if (e.code === "KeyQ") input.camYaw += 0.3; if (e.code === "KeyR") input.camYaw -= 0.3; keys.add(e.code); sync(); };
    const up = (e: KeyboardEvent) => { keys.delete(e.code); sync(); };
    window.addEventListener("keydown", down); window.addEventListener("keyup", up);
    const reset = () => { keys.clear(); input.x = 0; input.y = 0; input.run = false; input.jump = false; input.emote = false; drag.current = null; };
    window.addEventListener("blur", reset);
    return () => { reset(); setState({ panel: null }); window.removeEventListener("blur", reset); window.removeEventListener("resize", check); window.removeEventListener("keydown", down); window.removeEventListener("keyup", up); };
  }, []);

  const enter = async () => {
    setEntered(true);
    try { await document.documentElement.requestFullscreen?.(); } catch { /* blocked */ }
    try { await (screen.orientation as ScreenOrientation & { lock?: (o: string) => Promise<void> }).lock?.("landscape"); } catch { /* unsupported */ }
  };
  const exit = () => { if (document.fullscreenElement) document.exitFullscreen().catch(() => {}); };

  const dpr: [number, number] = quality === "low" ? [0.75, 1] : quality === "medium" ? [1, 1.5] : [1, 2];
  const loc = nearby === "shop" || nearby === "games" || nearby === "friends" ? nearby : null;

  return (
    <div dir="rtl" className="fixed inset-0 overflow-hidden bg-background select-none">
      <div
        className="absolute inset-0 touch-none"
        onPointerDown={(e) => { drag.current = { id: e.pointerId, x: e.clientX }; }}
        onPointerMove={(e) => { if (drag.current?.id === e.pointerId) { input.camYaw -= (e.clientX - drag.current.x) * 0.006; drag.current.x = e.clientX; } }}
        onPointerUp={() => (drag.current = null)}
        onPointerCancel={() => (drag.current = null)}
      >
        <Canvas shadows={quality !== "low"} dpr={dpr} gl={{ antialias: quality !== "low", powerPreference: "high-performance" }} camera={{ fov: 60, position: [0, 6, 14] }}>
          <Suspense fallback={null}><Scene quality={quality} /></Suspense>
        </Canvas>
      </div>

      {/* HUD */}
      <div className="safe-pad pointer-events-none absolute inset-0 z-10 flex flex-col justify-between">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div className="glass pointer-events-auto flex items-center gap-2 rounded-full py-1 pe-3 ps-1">
            <div className="neon-bg grid size-10 place-items-center rounded-full font-display text-lg text-primary-foreground">{profile.name[0]}</div>
            <div className="text-xs leading-tight">
              <p className="font-semibold">{profile.name} · Lv {profile.level}</p>
              <div className="mt-1 h-1.5 w-20 overflow-hidden rounded-full bg-muted"><div className="neon-bg h-full" style={{ width: `${(profile.xp / (profile.level * 100)) * 100}%` }} /></div>
            </div>
            <span className="ms-2 text-xs text-gold">🪙 {profile.coins}</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {([["games", "🎮", "الألعاب"], ["friends", "👥", "الأصدقاء"], ["chat", "💬", "الدردشة"], ["notifications", "🔔", "الإشعارات"], ["missions", "🎯", "المهام"], ["settings", "⚙️", "الإعدادات"]] as const).map(([p, ic, lb]) => (
              <button key={p} aria-label={lb} className="glass pointer-events-auto grid size-11 place-items-center rounded-full" onClick={() => setState((s) => ({ panel: s.panel === p ? null : p }))}>{ic}</button>
            ))}
            {onExit ? <Button variant="ghost" size="icon" title="رجوع للتطبيق" aria-label="رجوع للتطبيق" className="glass pointer-events-auto size-11 rounded-full" onClick={() => { exit(); onExit(); }}>⏏</Button> : <Link to="/" onClick={exit} aria-label="خروج" className="glass pointer-events-auto grid size-11 place-items-center rounded-full">⏏</Link>}
          </div>
        </div>

        <div className="flex flex-col items-center gap-2">
          {toast && <div className="glass rounded-full px-4 py-2 text-sm">{toast}</div>}
          {loc && (
            <button className="neon-bg neon-shadow pointer-events-auto min-h-12 rounded-full px-6 font-semibold text-primary-foreground" onClick={() => setState({ panel: loc })}>
              ادخل {loc === "shop" ? "المتجر" : loc === "games" ? "الألعاب" : "بوابة الأصدقاء"}
            </button>
          )}
        </div>

        <div dir="ltr" className="flex items-end justify-between">
          <Joystick />
          <div className="flex items-end gap-3">
            <div className="flex flex-col gap-3">
              <RoundBtn label="رقصة" icon="💃" onDown={() => { input.emote = true; }} />
              <RoundBtn label="ركض" icon="⚡" onDown={() => { input.run = true; }} onUp={() => { input.run = false; }} />
            </div>
            <RoundBtn big label="قفز" icon="⤒" onDown={() => { input.jump = true; }} />
          </div>
        </div>
      </div>

      <ChatBox />
      <Panel />

      {!entered && (
        <div className="sky-bg absolute inset-0 z-40 grid place-items-center p-6 text-center">
          <div>
            <p className="font-display text-6xl">عالمي</p>
            <p className="mt-2 text-sm text-muted-foreground">أفضل تجربة بوضع أفقي وملء الشاشة · Best in landscape</p>
            <p className="mt-1 text-xs text-muted-foreground">لوحة المفاتيح: WASD · Shift ركض · Space قفز · E رقصة · اسحب لتدوير الكاميرا</p>
            <button onClick={enter} className="neon-bg neon-shadow mt-6 min-h-12 rounded-full px-8 font-semibold text-primary-foreground">ادخل الساحة · Enter</button>
          </div>
        </div>
      )}
      {entered && portrait && (
        <div className="absolute inset-0 z-50 grid place-items-center bg-background/90 p-6 text-center">
          <div><p className="text-5xl">📱↻</p><p className="mt-3 font-semibold">أدِر جهازك للوضع الأفقي</p><p className="text-xs text-muted-foreground">Rotate your device to landscape</p>
            <button className="mt-4 min-h-11 rounded-full bg-muted px-5 text-sm" onClick={() => setPortrait(false)}>متابعة على أي حال</button></div>
        </div>
      )}
    </div>
  );
}
