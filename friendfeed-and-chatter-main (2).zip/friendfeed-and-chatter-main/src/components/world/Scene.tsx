import { useFrame, useThree } from "@react-three/fiber";
import { Environment, Lightformer, Sparkles, Text, Billboard } from "@react-three/drei";
import { useMemo, useRef } from "react";
import * as THREE from "three";
import { input, setState, getState, showToast, addXp, type Quality } from "@/lib/game-store";

const WALK = 4, RUN = 8, GRAV = 22, JUMP_V = 8;

export const LOCATIONS = [
  { id: "shop", label: "المتجر", pos: [-12, 0, -6] as const, color: "#ff7ad9" },
  { id: "games", label: "الألعاب", pos: [12, 0, -6] as const, color: "#7af0ff" },
  { id: "friends", label: "بوابة الأصدقاء", pos: [0, 0, -16] as const, color: "#ffd36b" },
];
const NPCS: { id: string; name: string; pos: [number, number, number]; color: string; line: string }[] = [
  { id: "n1", name: "ليان", pos: [-5, 0, 4], color: "#ff9bd2", line: "أهلاً! نوّرت الساحة ✨" },
  { id: "n2", name: "سالم", pos: [6, 0, 3], color: "#8fd3ff", line: "جرّب سباق النجوم!" },
  { id: "n3", name: "ريم", pos: [3, 0, -9], color: "#b7ff9b", line: "البلورة تتوهج الليلة 💜" },
];

function Avatar({ color, emote }: { color: string; emote?: React.MutableRefObject<number> }) {
  const g = useRef<THREE.Group>(null);
  useFrame((s) => {
    if (g.current && emote) g.current.rotation.y = emote.current > 0 ? s.clock.elapsedTime * 10 : 0;
  });
  return (
    <group ref={g}>
      <mesh position={[0, 0.75, 0]} castShadow>
        <capsuleGeometry args={[0.35, 0.7, 6, 12]} />
        <meshStandardMaterial color={color} roughness={0.4} />
      </mesh>
      <mesh position={[0, 1.55, 0]} castShadow>
        <sphereGeometry args={[0.3, 16, 16]} />
        <meshStandardMaterial color="#f3d6c4" roughness={0.6} />
      </mesh>
      <mesh position={[0, 1.6, 0.26]}>
        <boxGeometry args={[0.36, 0.1, 0.06]} />
        <meshStandardMaterial color="#1a1030" emissive={color} emissiveIntensity={1.5} />
      </mesh>
    </group>
  );
}

function Crystal() {
  const r = useRef<THREE.Mesh>(null);
  useFrame((s, d) => {
    if (!r.current) return;
    r.current.rotation.y += d * 0.4;
    r.current.position.y = 4 + Math.sin(s.clock.elapsedTime) * 0.3;
  });
  return (
    <group>
      <mesh position={[0, 0.4, 0]} receiveShadow>
        <cylinderGeometry args={[3, 3.4, 0.8, 8]} />
        <meshStandardMaterial color="#2a1a48" metalness={0.6} roughness={0.3} />
      </mesh>
      <mesh ref={r} position={[0, 4, 0]} castShadow>
        <octahedronGeometry args={[1.6, 0]} />
        <meshStandardMaterial color="#c58bff" emissive="#9b4dff" emissiveIntensity={2} metalness={0.2} roughness={0.1} transparent opacity={0.92} />
      </mesh>
      <pointLight position={[0, 4, 0]} color="#b06bff" intensity={40} distance={22} />
    </group>
  );
}

function Ground() {
  const tex = useMemo(() => {
    const c = document.createElement("canvas");
    c.width = c.height = 512;
    const x = c.getContext("2d")!;
    x.fillStyle = "#1a1230"; x.fillRect(0, 0, 512, 512);
    x.strokeStyle = "#3a2766"; x.lineWidth = 3;
    for (let i = 0; i <= 512; i += 64) { x.beginPath(); x.moveTo(i, 0); x.lineTo(i, 512); x.stroke(); x.beginPath(); x.moveTo(0, i); x.lineTo(512, i); x.stroke(); }
    const t = new THREE.CanvasTexture(c);
    t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(12, 12); t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }, []);
  return (
    <>
      <mesh rotation-x={-Math.PI / 2} receiveShadow>
        <circleGeometry args={[40, 48]} />
        <meshStandardMaterial map={tex} roughness={0.7} metalness={0.2} />
      </mesh>
      {[6, 11].map((rad) => (
        <mesh key={rad} rotation-x={-Math.PI / 2} position-y={0.02}>
          <ringGeometry args={[rad, rad + 0.15, 64]} />
          <meshBasicMaterial color="#b86bff" toneMapped={false} />
        </mesh>
      ))}
      {LOCATIONS.map((l) => (
        <mesh key={l.id} position={[l.pos[0] / 2, 0.03, l.pos[2] / 2]} rotation={[-Math.PI / 2, 0, Math.atan2(l.pos[0], l.pos[2])]}>
          <planeGeometry args={[0.6, Math.hypot(l.pos[0], l.pos[2])]} />
          <meshBasicMaterial color={l.color} transparent opacity={0.5} toneMapped={false} />
        </mesh>
      ))}
    </>
  );
}

function Building({ x, z, h, c }: { x: number; z: number; h: number; c: string }) {
  return (
    <group position={[x, 0, z]}>
      <mesh position={[0, h / 2, 0]} castShadow receiveShadow>
        <boxGeometry args={[4, h, 4]} />
        <meshStandardMaterial color="#1c1436" metalness={0.5} roughness={0.4} />
      </mesh>
      {Array.from({ length: Math.floor(h / 2) }).map((_, i) => (
        <mesh key={i} position={[0, 1.5 + i * 2, 2.01]}>
          <planeGeometry args={[3, 0.25]} />
          <meshBasicMaterial color={c} toneMapped={false} />
        </mesh>
      ))}
    </group>
  );
}

function Location({ l }: { l: (typeof LOCATIONS)[number] }) {
  return (
    <group position={[l.pos[0], 0, l.pos[2]]}>
      <mesh position={[0, 2, 0]} castShadow>
        <torusGeometry args={[2, 0.25, 12, 40]} />
        <meshStandardMaterial color={l.color} emissive={l.color} emissiveIntensity={2} toneMapped={false} />
      </mesh>
      <mesh position={[0, 2, 0]}>
        <circleGeometry args={[1.8, 32]} />
        <meshBasicMaterial color={l.color} transparent opacity={0.18} side={THREE.DoubleSide} />
      </mesh>
      <Billboard position={[0, 4.8, 0]}>
        <Text fontSize={0.7} color="white" outlineWidth={0.04} outlineColor={l.color}>{l.label}</Text>
      </Billboard>
    </group>
  );
}

function Lamp({ x, z }: { x: number; z: number }) {
  return (
    <group position={[x, 0, z]}>
      <mesh position={[0, 1.5, 0]}><cylinderGeometry args={[0.07, 0.1, 3, 6]} /><meshStandardMaterial color="#3a2d5c" /></mesh>
      <mesh position={[0, 3.1, 0]}><sphereGeometry args={[0.25, 12, 12]} /><meshBasicMaterial color="#ffd8ff" toneMapped={false} /></mesh>
    </group>
  );
}

function Tree({ x, z }: { x: number; z: number }) {
  return (
    <group position={[x, 0, z]}>
      <mesh position={[0, 0.8, 0]} castShadow><cylinderGeometry args={[0.15, 0.2, 1.6, 6]} /><meshStandardMaterial color="#3b2a4a" /></mesh>
      <mesh position={[0, 2.2, 0]} castShadow><coneGeometry args={[1, 2.2, 7]} /><meshStandardMaterial color="#5a2f8a" emissive="#3d1470" emissiveIntensity={0.5} flatShading /></mesh>
    </group>
  );
}

function NPC({ n }: { n: (typeof NPCS)[number] }) {
  const g = useRef<THREE.Group>(null);
  useFrame((s) => { if (g.current) g.current.position.y = Math.abs(Math.sin(s.clock.elapsedTime * 2 + n.pos[0])) * 0.08; });
  return (
    <group position={n.pos as [number, number, number]}>
      <group ref={g}><Avatar color={n.color} /></group>
      <Billboard position={[0, 2.3, 0]}><Text fontSize={0.35} color="white" outlineWidth={0.03} outlineColor="#000">{n.name}</Text></Billboard>
    </group>
  );
}

function Player() {
  const ref = useRef<THREE.Group>(null);
  const vel = useRef(new THREE.Vector3());
  const vy = useRef(0);
  const emote = useRef(0);
  const greeted = useRef(new Set<string>());
  const { camera } = useThree();
  const camPos = useRef(new THREE.Vector3(0, 6, 14));

  useFrame((_, raw) => {
    const dt = Math.min(raw, 0.05);
    const p = ref.current; if (!p) return;
    const yaw = input.camYaw;
    // camera-relative movement (forward = -z rotated by yaw)
    const fx = -Math.sin(yaw), fz = -Math.cos(yaw);
    const rx = Math.cos(yaw), rz = -Math.sin(yaw);
    const mx = fx * input.y + rx * input.x, mz = fz * input.y + rz * input.x;
    const mag = Math.min(1, Math.hypot(mx, mz));
    const speed = input.run ? RUN : WALK;
    const target = new THREE.Vector3(mx, 0, mz).normalize().multiplyScalar(mag * speed);
    if (mag < 0.05) target.set(0, 0, 0);
    vel.current.lerp(target, 1 - Math.exp(-10 * dt));
    p.position.x += vel.current.x * dt; p.position.z += vel.current.z * dt;
    const r = Math.hypot(p.position.x, p.position.z);
    if (r > 36) { p.position.x *= 36 / r; p.position.z *= 36 / r; }
    if (r < 3.6) { const k = 3.6 / Math.max(r, 0.01); p.position.x *= k; p.position.z *= k; }
    if (vel.current.lengthSq() > 0.1) p.rotation.y = Math.atan2(vel.current.x, vel.current.z);

    if (input.jump && p.position.y <= 0.001) {
      vy.current = JUMP_V; input.jump = false;
      const ms = getState().missions.map((m) => m.id === "m3" ? { ...m, progress: Math.min(m.goal, m.progress + 1) } : m);
      setState({ missions: ms });
    }
    input.jump = false;
    vy.current -= GRAV * dt; p.position.y = Math.max(0, p.position.y + vy.current * dt);
    if (p.position.y === 0) vy.current = 0;
    if (input.emote) { emote.current = 1.2; input.emote = false; }
    emote.current = Math.max(0, emote.current - dt);

    // proximity
    let near: string | null = null;
    for (const n of NPCS) {
      if (Math.hypot(p.position.x - n.pos[0], p.position.z - n.pos[2]) < 2.6) {
        near = n.id;
        if (!greeted.current.has(n.id)) {
          greeted.current.add(n.id);
          showToast(`${n.name}: ${n.line}`);
          addXp(10);
          setState((s) => ({ missions: s.missions.map((m) => m.id === "m1" ? { ...m, progress: Math.min(m.goal, m.progress + 1) } : m) }));
        }
      }
    }
    for (const l of LOCATIONS) if (Math.hypot(p.position.x - l.pos[0], p.position.z - l.pos[2]) < 3.2) near = l.id;
    if (near !== getState().nearby) setState({ nearby: near });

    // camera follow
    const off = new THREE.Vector3(Math.sin(yaw) * 9, 5.5, Math.cos(yaw) * 9);
    camPos.current.lerp(p.position.clone().add(off), 1 - Math.exp(-6 * dt));
    camera.position.copy(camPos.current);
    camera.lookAt(p.position.x, p.position.y + 1.4, p.position.z);
  });

  return <group ref={ref} position={[0, 0, 8]}><Avatar color={getState().profile.avatarColor} emote={emote} /></group>;
}

export function Scene({ quality }: { quality: Quality }) {
  const buildings = useMemo(() => {
    const arr: { x: number; z: number; h: number; c: string }[] = [];
    const n = quality === "low" ? 8 : 14;
    const cols = ["#b46cff", "#ff7ad9", "#7af0ff", "#ffd36b"];
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2;
      arr.push({ x: Math.sin(a) * 30, z: Math.cos(a) * 30, h: 6 + ((i * 7) % 10), c: cols[i % 4]! });
    }
    return arr;
  }, [quality]);

  return (
    <>
      <color attach="background" args={["#120a22"]} />
      <fog attach="fog" args={["#120a22", 20, 70]} />
      <ambientLight intensity={0.55} color="#c9b6ff" />
      <hemisphereLight args={["#8a6bff", "#1a0f2e", 0.6]} />
      <directionalLight position={[10, 20, 8]} intensity={0.9} color="#e6d6ff" castShadow={quality !== "low"} shadow-mapSize={[1024, 1024]} shadow-camera-left={-25} shadow-camera-right={25} shadow-camera-top={25} shadow-camera-bottom={-25} />
      {quality !== "low" && (
        <Environment resolution={64}>
          <Lightformer intensity={2} color="#b06bff" position={[0, 5, -10]} scale={[20, 5, 1]} />
          <Lightformer intensity={1} color="#7af0ff" position={[-10, 2, 0]} rotation-y={Math.PI / 2} scale={[20, 2, 1]} />
        </Environment>
      )}
      <Ground />
      <Crystal />
      {buildings.map((b, i) => <Building key={i} {...b} />)}
      {LOCATIONS.map((l) => <Location key={l.id} l={l} />)}
      {[...Array(8)].map((_, i) => { const a = (i / 8) * Math.PI * 2 + 0.3; return <Lamp key={i} x={Math.sin(a) * 8.5} z={Math.cos(a) * 8.5} />; })}
      {[...Array(quality === "low" ? 6 : 12)].map((_, i) => { const a = (i / 12) * Math.PI * 2; return <Tree key={i} x={Math.sin(a) * 20} z={Math.cos(a) * 20} />; })}
      {NPCS.map((n) => <NPC key={n.id} n={n} />)}
      {quality !== "low" && <Sparkles count={quality === "high" ? 160 : 70} scale={[40, 12, 40]} position={[0, 5, 0]} size={3} color="#d9b3ff" speed={0.3} />}
      <Player />
    </>
  );
}
