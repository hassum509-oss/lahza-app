// Config-driven 3D world renderer: sky, day cycle, weather, terrain, props.
import { useFrame, useThree } from "@react-three/fiber";
import { Environment, Lightformer, Sparkles, Stars, Cloud, Billboard, Text } from "@react-three/drei";
import { useMemo, useRef } from "react";
import * as THREE from "three";
import { input, setState, getState, showToast, addXp, type Quality } from "@/lib/game-store";
import { SIZE_RADIUS, type WorldConfig, type TimeOfDay } from "@/lib/worlds";

const WALK = 4, RUN = 8, GRAV = 22, JUMP_V = 8;

/* ---------- time-of-day palettes ---------- */
interface Palette { sky: string; fog: string; ambient: string; sun: string; sunI: number; stars: boolean; ground: string }
const PALETTES: Record<TimeOfDay, Palette> = {
  sunrise: { sky: "#3a2340", fog: "#4a2a48", ambient: "#e8b48a", sun: "#ffb37a", sunI: 0.9, stars: false, ground: "#2a1e34" },
  morning: { sky: "#7ab8e6", fog: "#9cc8ea", ambient: "#dfeaf5", sun: "#fff2d0", sunI: 1.3, stars: false, ground: "#3a4a3a" },
  sunset: { sky: "#4a2340", fog: "#5a2a44", ambient: "#f0a878", sun: "#ff8a5a", sunI: 1.0, stars: false, ground: "#2e2038" },
  night: { sky: "#0d081d", fog: "#140c26", ambient: "#8a7ac0", sun: "#b9a8ff", sunI: 0.5, stars: true, ground: "#181028" },
};

function lerpPalette(a: Palette, b: Palette, t: number): Palette {
  const c = (x: string, y: string) => `#${new THREE.Color(x).lerp(new THREE.Color(y), t).getHexString()}`;
  return { sky: c(a.sky, b.sky), fog: c(a.fog, b.fog), ambient: c(a.ambient, b.ambient), sun: c(a.sun, b.sun), sunI: a.sunI + (b.sunI - a.sunI) * t, stars: t > 0.5 ? b.stars : a.stars, ground: c(a.ground, b.ground) };
}
const CYCLE: TimeOfDay[] = ["sunrise", "morning", "sunset", "night"];

/* ---------- sky / environment ---------- */
function Sky({ config, quality }: { config: WorldConfig; quality: Quality }) {
  const palRef = useRef(PALETTES[config.timeOfDay]);
  const bg = useRef(new THREE.Color(config.timeOfDay === "night" ? "#0d081d" : PALETTES[config.timeOfDay].sky));
  const fogRef = useRef<THREE.Fog>(null);
  const ambRef = useRef<THREE.AmbientLight>(null);
  const sunRef = useRef<THREE.DirectionalLight>(null);
  const t = useRef(0);

  useFrame((_, raw) => {
    const dt = Math.min(raw, 0.05);
    if (config.dayCycle) {
      // full day in 4 minutes
      t.current = (t.current + dt / 240) % 1;
      const seg = t.current * 4;
      const i = Math.floor(seg) % 4;
      const a = PALETTES[CYCLE[i]!]!, b = PALETTES[CYCLE[(i + 1) % 4]!]!;
      palRef.current = lerpPalette(a, b, seg - Math.floor(seg));
    } else {
      palRef.current = PALETTES[config.timeOfDay];
    }
    const p = palRef.current;
    bg.current.lerp(new THREE.Color(p.sky), 1 - Math.exp(-2 * dt));
    if (fogRef.current) fogRef.current.color.lerp(new THREE.Color(p.fog), 1 - Math.exp(-2 * dt));
    if (ambRef.current) ambRef.current.color.lerp(new THREE.Color(p.ambient), 1 - Math.exp(-2 * dt));
    if (sunRef.current) {
      sunRef.current.color.lerp(new THREE.Color(p.sun), 1 - Math.exp(-2 * dt));
      sunRef.current.intensity += (p.sunI - sunRef.current.intensity) * (1 - Math.exp(-2 * dt));
    }
  });

  const pal = PALETTES[config.timeOfDay];
  const showStars = config.dayCycle || pal.stars;
  return (
    <>
      <primitive object={bg.current} attach="background" />
      <fog ref={fogRef} attach="fog" args={[pal.fog, config.weather.fog ? 8 : 22, config.weather.fog ? 40 : 85]} />
      <ambientLight ref={ambRef} intensity={0.55} color={pal.ambient} />
      <hemisphereLight args={[pal.sky, pal.ground, 0.5]} />
      <directionalLight ref={sunRef} position={[12, 20, 8]} intensity={pal.sunI} color={pal.sun} castShadow={quality !== "low"} shadow-mapSize={[1024, 1024]} shadow-camera-left={-30} shadow-camera-right={30} shadow-camera-top={30} shadow-camera-bottom={-30} />
      {showStars && quality !== "low" && <Stars radius={90} depth={40} count={quality === "ultra" ? 4000 : 1800} factor={4} saturation={0.4} fade speed={config.weather.wind ? 2 : 0.6} />}
      {quality !== "low" && !config.weather.rain && (
        <>
          <Cloud position={[-14, 14, -18]} speed={config.weather.wind ? 0.6 : 0.15} opacity={0.35} segments={12} color={pal.fog} />
          <Cloud position={[16, 16, -8]} speed={config.weather.wind ? 0.5 : 0.12} opacity={0.28} segments={10} color={pal.fog} />
        </>
      )}
      {quality !== "low" && (
        <Environment resolution={64}>
          <Lightformer intensity={2} color="#b06bff" position={[0, 5, -10]} scale={[20, 5, 1]} />
          <Lightformer intensity={1} color="#7af0ff" position={[-10, 2, 0]} rotation-y={Math.PI / 2} scale={[20, 2, 1]} />
        </Environment>
      )}
    </>
  );
}

/* ---------- rain ---------- */
function Rain({ count }: { count: number }) {
  const ref = useRef<THREE.Points>(null);
  const geo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    const pos = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 50;
      pos[i * 3 + 1] = Math.random() * 20;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 50;
    }
    g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    return g;
  }, [count]);
  useFrame((_, raw) => {
    const dt = Math.min(raw, 0.05);
    if (!ref.current) return;
    const pos = ref.current.geometry.attributes["position"] as THREE.BufferAttribute;
    for (let i = 0; i < count; i++) {
      let y = pos.getY(i) - dt * 18;
      if (y < 0) y = 20;
      pos.setY(i, y);
    }
    pos.needsUpdate = true;
  });
  return (
    <points ref={ref} geometry={geo}>
      <pointsMaterial color="#9db8e8" size={0.08} transparent opacity={0.6} sizeAttenuation />
    </points>
  );
}

/* ---------- terrain & props ---------- */
const TEMPLATE_GROUND: Record<WorldConfig["template"], { base: string; line: string; tree: string; rock: string }> = {
  nature: { base: "#1e2e22", line: "#2e4634", tree: "#3f7a4a", rock: "#5a5a66" },
  city: { base: "#1a1230", line: "#3a2766", tree: "#5a2f8a", rock: "#4a4460" },
  space: { base: "#100a20", line: "#2a1a4a", tree: "#6a3fb0", rock: "#3a3460" },
  fantasy: { base: "#221232", line: "#3d2260", tree: "#7a3fb0", rock: "#4a3a70" },
  beach: { base: "#3a3220", line: "#5a4e30", tree: "#4a8a5a", rock: "#8a7a5a" },
};

function Ground({ config }: { config: WorldConfig }) {
  const R = SIZE_RADIUS[config.size];
  const colors = TEMPLATE_GROUND[config.template];
  const tex = useMemo(() => {
    const c = document.createElement("canvas");
    c.width = c.height = 512;
    const x = c.getContext("2d")!;
    x.fillStyle = colors.base; x.fillRect(0, 0, 512, 512);
    x.strokeStyle = colors.line; x.lineWidth = 2;
    for (let i = 0; i <= 512; i += 64) { x.beginPath(); x.moveTo(i, 0); x.lineTo(i, 512); x.stroke(); x.beginPath(); x.moveTo(0, i); x.lineTo(512, i); x.stroke(); }
    const t = new THREE.CanvasTexture(c);
    t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(Math.round(R / 3), Math.round(R / 3)); t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }, [colors.base, colors.line, R]);
  return (
    <mesh rotation-x={-Math.PI / 2} receiveShadow>
      <circleGeometry args={[R + 4, 48]} />
      <meshStandardMaterial map={tex} roughness={0.8} metalness={0.1} />
    </mesh>
  );
}

function Lake({ R }: { R: number }) {
  const ref = useRef<THREE.Mesh>(null);
  useFrame((s) => { if (ref.current) (ref.current.material as THREE.MeshStandardMaterial).opacity = 0.65 + Math.sin(s.clock.elapsedTime * 1.5) * 0.08; });
  return (
    <mesh ref={ref} rotation-x={-Math.PI / 2} position={[R * 0.35, 0.04, R * 0.3]}>
      <circleGeometry args={[R * 0.22, 32]} />
      <meshStandardMaterial color="#3a8ac8" metalness={0.9} roughness={0.05} transparent opacity={0.7} />
    </mesh>
  );
}

function scatter(n: number, R: number, minR: number, seed: number): [number, number][] {
  const out: [number, number][] = [];
  for (let i = 0; i < n; i++) {
    const a = ((i * 2.399963 + seed) % (Math.PI * 2));
    const r = minR + ((i * 37 + seed * 13) % 100) / 100 * (R - minR);
    out.push([Math.sin(a) * r, Math.cos(a) * r]);
  }
  return out;
}

function Props({ config, quality }: { config: WorldConfig; quality: Quality }) {
  const R = SIZE_RADIUS[config.size];
  const colors = TEMPLATE_GROUND[config.template];
  const mult = quality === "low" ? 0.5 : 1;
  const trees = useMemo(() => scatter(Math.round(config.trees * 20 * mult), R, 6, 1), [config.trees, R, mult]);
  const rocks = useMemo(() => scatter(Math.round(config.rocks * 14 * mult), R, 5, 2), [config.rocks, R, mult]);
  const buildings = useMemo(() => scatter(Math.round(config.buildings * 12 * mult), R, R * 0.55, 3), [config.buildings, R, mult]);
  const lamps = useMemo(() => scatter(Math.round(config.lighting * 10 * mult), R * 0.5, 4, 4), [config.lighting, R, mult]);
  const wind = config.weather.wind;

  return (
    <group>
      {trees.map(([x, z], i) => (
        <group key={`t${i}`} position={[x, 0, z]}>
          <mesh position={[0, 0.8, 0]} castShadow><cylinderGeometry args={[0.14, 0.2, 1.6, 6]} /><meshStandardMaterial color="#3b2a4a" /></mesh>
          <mesh position={[0, 2.2, 0]} castShadow><coneGeometry args={[1, 2.4, 7]} /><meshStandardMaterial color={colors.tree} emissive={colors.tree} emissiveIntensity={0.25} flatShading /></mesh>
        </group>
      ))}
      {rocks.map(([x, z], i) => (
        <mesh key={`r${i}`} position={[x, 0.3, z]} rotation={[i, i * 2, 0]} castShadow>
          <dodecahedronGeometry args={[0.4 + (i % 3) * 0.2, 0]} />
          <meshStandardMaterial color={colors.rock} roughness={0.9} flatShading />
        </mesh>
      ))}
      {buildings.map(([x, z], i) => {
        const h = 5 + ((i * 7) % 9);
        return (
          <group key={`b${i}`} position={[x, 0, z]}>
            <mesh position={[0, h / 2, 0]} castShadow receiveShadow>
              <boxGeometry args={[3.5, h, 3.5]} />
              <meshStandardMaterial color="#1c1436" metalness={0.5} roughness={0.4} />
            </mesh>
            {Array.from({ length: Math.floor(h / 2) }).map((_, j) => (
              <mesh key={j} position={[0, 1.5 + j * 2, 1.76]}>
                <planeGeometry args={[2.6, 0.22]} />
                <meshBasicMaterial color={["#b46cff", "#ff7ad9", "#7af0ff", "#ffd36b"][j % 4]!} toneMapped={false} />
              </mesh>
            ))}
          </group>
        );
      })}
      {lamps.map(([x, z], i) => (
        <group key={`l${i}`} position={[x, 0, z]}>
          <mesh position={[0, 1.5, 0]}><cylinderGeometry args={[0.07, 0.1, 3, 6]} /><meshStandardMaterial color="#3a2d5c" /></mesh>
          <mesh position={[0, 3.1, 0]}><sphereGeometry args={[0.25, 12, 12]} /><meshBasicMaterial color="#ffd8ff" toneMapped={false} /></mesh>
        </group>
      ))}
      {wind && quality !== "low" && <Sparkles count={60} scale={[R * 1.4, 6, R * 1.4]} position={[0, 3, 0]} size={2} color="#cfe8ff" speed={2.5} />}
    </group>
  );
}

/* ---------- interactive zones & NPCs ---------- */
const ZONES = [
  { id: "shop", label: "المتجر", angle: 0.6, color: "#ff7ad9" },
  { id: "games", label: "الألعاب", angle: 2.4, color: "#7af0ff" },
  { id: "friends", label: "بوابة الأصدقاء", angle: 4.4, color: "#ffd36b" },
];
const NPC_LINES = ["أهلاً بك في عالمي! ✨", "يوم جميل للتجوّل", "جرّبت الألعاب؟", "السماء رائعة الليلة"];
const NPC_NAMES = ["ليان", "سالم", "ريم"];

function Zones({ R }: { R: number }) {
  return (
    <>
      {ZONES.map((z) => {
        const x = Math.sin(z.angle) * R * 0.55, zz = Math.cos(z.angle) * R * 0.55;
        return (
          <group key={z.id} position={[x, 0, zz]}>
            <mesh position={[0, 2, 0]} castShadow>
              <torusGeometry args={[1.8, 0.22, 12, 40]} />
              <meshStandardMaterial color={z.color} emissive={z.color} emissiveIntensity={2} toneMapped={false} />
            </mesh>
            <mesh position={[0, 2, 0]}>
              <circleGeometry args={[1.6, 32]} />
              <meshBasicMaterial color={z.color} transparent opacity={0.18} side={THREE.DoubleSide} />
            </mesh>
            <Billboard position={[0, 4.4, 0]}>
              <Text fontSize={0.6} color="white" outlineWidth={0.04} outlineColor={z.color}>{z.label}</Text>
            </Billboard>
          </group>
        );
      })}
    </>
  );
}

function Avatar({ color, emote }: { color: string; emote?: React.MutableRefObject<number> }) {
  const g = useRef<THREE.Group>(null);
  useFrame((s) => { if (g.current && emote) g.current.rotation.y = emote.current > 0 ? s.clock.elapsedTime * 10 : 0; });
  return (
    <group ref={g}>
      <mesh position={[0, 0.75, 0]} castShadow><capsuleGeometry args={[0.35, 0.7, 6, 12]} /><meshStandardMaterial color={color} roughness={0.4} /></mesh>
      <mesh position={[0, 1.55, 0]} castShadow><sphereGeometry args={[0.3, 16, 16]} /><meshStandardMaterial color="#f3d6c4" roughness={0.6} /></mesh>
      <mesh position={[0, 1.6, 0.26]}><boxGeometry args={[0.36, 0.1, 0.06]} /><meshStandardMaterial color="#1a1030" emissive={color} emissiveIntensity={1.5} /></mesh>
    </group>
  );
}

function Npcs({ R }: { R: number }) {
  const spots = useMemo(() => scatter(3, R * 0.3, 4, 7), [R]);
  return (
    <>
      {spots.map(([x, z], i) => (
        <group key={i} position={[x, 0, z]}>
          <Avatar color={["#ff9bd2", "#8fd3ff", "#b7ff9b"][i % 3]!} />
          <Billboard position={[0, 2.3, 0]}><Text fontSize={0.35} color="white" outlineWidth={0.03} outlineColor="#000">{NPC_NAMES[i]}</Text></Billboard>
        </group>
      ))}
    </>
  );
}

function Player({ R }: { R: number }) {
  const ref = useRef<THREE.Group>(null);
  const vel = useRef(new THREE.Vector3());
  const vy = useRef(0);
  const emote = useRef(0);
  const greeted = useRef(new Set<number>());
  const { camera } = useThree();
  const camPos = useRef(new THREE.Vector3(0, 6, 14));
  const npcSpots = useMemo(() => scatter(3, R * 0.3, 4, 7), [R]);

  useFrame((_, raw) => {
    const dt = Math.min(raw, 0.05);
    const p = ref.current; if (!p) return;
    const yaw = input.camYaw;
    const fx = -Math.sin(yaw), fz = -Math.cos(yaw);
    const rx = Math.cos(yaw), rz = -Math.sin(yaw);
    const mx = fx * input.y + rx * input.x, mz = fz * input.y + rz * input.x;
    const mag = Math.min(1, Math.hypot(mx, mz));
    const speed = input.run ? RUN : WALK;
    const target = new THREE.Vector3(mx, 0, mz).normalize().multiplyScalar(mag * speed);
    if (mag < 0.05) target.set(0, 0, 0);
    vel.current.lerp(target, 1 - Math.exp(-10 * dt));
    p.position.x += vel.current.x * dt; p.position.z += vel.current.z * dt;
    const r = Math.hypot(p.position.x, p.position.z);
    if (r > R) { p.position.x *= R / r; p.position.z *= R / r; }
    if (vel.current.lengthSq() > 0.1) p.rotation.y = Math.atan2(vel.current.x, vel.current.z);

    if (input.jump && p.position.y <= 0.001) {
      vy.current = JUMP_V; input.jump = false;
      const ms = getState().missions.map((m) => m.id === "m3" ? { ...m, progress: Math.min(m.goal, m.progress + 1) } : m);
      setState({ missions: ms });
    }
    input.jump = false;
    vy.current -= GRAV * dt; p.position.y = Math.max(0, p.position.y + vy.current * dt);
    if (p.position.y === 0) vy.current = 0;
    if (input.emote) { emote.current = 1.2; input.emote = false; }
    emote.current = Math.max(0, emote.current - dt);

    let near: string | null = null;
    npcSpots.forEach(([x, z], i) => {
      if (Math.hypot(p.position.x - x, p.position.z - z) < 2.6) {
        near = `npc${i}`;
        if (!greeted.current.has(i)) {
          greeted.current.add(i);
          showToast(`${NPC_NAMES[i]}: ${NPC_LINES[i % NPC_LINES.length]}`);
          addXp(10);
          setState((s) => ({ missions: s.missions.map((m) => m.id === "m1" ? { ...m, progress: Math.min(m.goal, m.progress + 1) } : m) }));
        }
      }
    });
    for (const z of ZONES) {
      const zx = Math.sin(z.angle) * R * 0.55, zz = Math.cos(z.angle) * R * 0.55;
      if (Math.hypot(p.position.x - zx, p.position.z - zz) < 3.2) near = z.id;
    }
    if (near !== getState().nearby) setState({ nearby: near });

    const off = new THREE.Vector3(Math.sin(yaw) * 9, 5.5, Math.cos(yaw) * 9);
    camPos.current.lerp(p.position.clone().add(off), 1 - Math.exp(-6 * dt));
    camera.position.copy(camPos.current);
    camera.lookAt(p.position.x, p.position.y + 1.4, p.position.z);
  });

  return <group ref={ref} position={[0, 0, 8]}><Avatar color={getState().profile.avatarColor} emote={emote} /></group>;
}

export function CustomScene({ config, quality }: { config: WorldConfig; quality: Quality }) {
  const R = SIZE_RADIUS[config.size];
  return (
    <>
      <Sky config={config} quality={quality} />
      <Ground config={config} />
      {config.lake && <Lake R={R} />}
      <Props config={config} quality={quality} />
      <Zones R={R} />
      <Npcs R={R} />
      {config.weather.rain && quality !== "low" && <Rain count={quality === "ultra" ? 1200 : 500} />}
      <Player R={R} />
    </>
  );
}
