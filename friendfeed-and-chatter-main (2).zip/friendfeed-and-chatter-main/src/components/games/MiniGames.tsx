// Playable rounds and records are local to this device.
import { useEffect, useRef, useState } from "react";
import { ArrowRight, Play, RotateCcw, Trophy, Timer, Pause, Star, Gem, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { addXp, addCoins, getState } from "@/lib/game-store";
import { recordScore, topScores } from "@/lib/profile-store";
import { games } from "@/services/mock-data";
import { nextPlatform, QUIZ, ROUND_SECONDS, roundReward } from "@/lib/mini-game-rules";

function useRound(seconds: number, paused: boolean, score: React.RefObject<number>, onDone: (score: number) => void) {
  const [left, setLeft] = useState(seconds);
  const remaining = useRef(seconds * 1000);
  const done = useRef(false);
  const finish = useRef(onDone);
  finish.current = onDone;
  useEffect(() => {
    if (paused || done.current) return;
    let previous = performance.now();
    const tick = setInterval(() => {
      const now = performance.now();
      remaining.current = Math.max(0, remaining.current - (now - previous)); previous = now;
      setLeft(Math.ceil(remaining.current / 1000));
      if (remaining.current === 0 && !done.current) { done.current = true; clearInterval(tick); finish.current(score.current); }
    }, 100);
    return () => clearInterval(tick);
  }, [paused, score]);
  return left;
}

function RoundStats({ score, left }: { score: number; left: number }) {
  return <div className="flex items-center justify-between border-b border-border pb-3 text-sm"><span className="flex items-center gap-2 text-gold"><Star className="size-4" />{score} نقطة</span><span className={`flex items-center gap-2 tabular-nums ${left <= 5 ? "text-destructive" : "text-muted-foreground"}`}><Timer className="size-4" />{left} ث</span></div>;
}

function StarRace({ onDone, paused }: { onDone: (score: number) => void; paused: boolean }) {
  const [stars, setStars] = useState<{ id: number; x: number; y: number }[]>([]);
  const [score, setScore] = useState(0);
  const scoreRef = useRef(0);
  const idRef = useRef(0);
  const collected = useRef(new Set<number>());
  const left = useRound(ROUND_SECONDS.g1, paused, scoreRef, onDone);
  useEffect(() => {
    if (paused) return;
    const spawn = () => setStars(s => [...s.slice(-5), { id: ++idRef.current, x: 5 + Math.random() * 77, y: 5 + Math.random() * 75 }]);
    spawn(); const timer = setInterval(spawn, 650);
    return () => clearInterval(timer);
  }, [paused]);
  return <div className="space-y-3"><RoundStats score={score} left={left} /><div className="relative h-64 overflow-hidden rounded-lg border border-border bg-background">
    {stars.map(s => <Button key={s.id} variant="ghost" size="icon" aria-label="نجمة" disabled={paused || left === 0} className="absolute size-12 text-gold transition-transform active:scale-90 [&_svg]:size-9" style={{ left: `${s.x}%`, top: `${s.y}%` }} onClick={() => {
      if (collected.current.has(s.id)) return; collected.current.add(s.id);
      scoreRef.current++; setScore(scoreRef.current); setStars(all => all.filter(st => st.id !== s.id));
    }}><Star fill="currentColor" /></Button>)}
    {paused && <div className="absolute inset-0 grid place-items-center bg-background/90 font-display text-3xl">متوقف مؤقتًا</div>}
  </div></div>;
}

function CrystalQuiz({ onDone }: { onDone: (score: number) => void }) {
  const [i, setI] = useState(0);
  const [score, setScore] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const pickedRef = useRef<number | null>(null);
  const q = QUIZ[i];
  if (!q) return null;
  const next = () => {
    if (i + 1 === QUIZ.length) onDone(score);
    else { pickedRef.current = null; setPicked(null); setI(i + 1); }
  };
  return <div className="space-y-4"><div className="flex justify-between text-sm text-muted-foreground"><span>السؤال {i + 1} / {QUIZ.length}</span><span>{score} صحيحة</span></div><div className="h-1 overflow-hidden rounded-full bg-muted"><div className="h-full bg-mint" style={{ width: `${(i + 1) / QUIZ.length * 100}%` }} /></div><h3 className="min-h-14 text-lg font-semibold">{q.q}</h3><div className="grid gap-2">{q.a.map((answer, j) => <Button key={answer} variant="secondary" disabled={picked !== null} className={`h-12 justify-start ${picked !== null && j === q.c ? "bg-mint/25 text-mint" : picked === j ? "bg-destructive/25 text-destructive" : ""}`} onClick={() => {
    if (pickedRef.current !== null) return; pickedRef.current = j; setPicked(j); if (j === q.c) setScore(s => s + 1);
  }}>{answer}</Button>)}</div>{picked !== null && <div className="flex items-center justify-between gap-2"><span className="text-sm">{picked === q.c ? "إجابة صحيحة! ✨" : `الإجابة الصحيحة: ${q.a[q.c]}`}</span><Button onClick={next}>{i + 1 === QUIZ.length ? "النتيجة" : "التالي"}<ArrowRight /></Button></div>}</div>;
}

function PlatformHop({ onDone, paused }: { onDone: (score: number) => void; paused: boolean }) {
  const [active, setActive] = useState(0);
  const activeRef = useRef(0);
  const [score, setScore] = useState(0);
  const scoreRef = useRef(0);
  const left = useRound(ROUND_SECONDS.g3, paused, scoreRef, onDone);
  const move = () => { activeRef.current = nextPlatform(activeRef.current); setActive(activeRef.current); };
  useEffect(() => { if (paused) return; const timer = setInterval(move, 900); return () => clearInterval(timer); }, [paused]);
  return <div className="space-y-3"><RoundStats score={score} left={left} /><div className="grid grid-cols-3 gap-2">{Array.from({ length: 9 }, (_, i) => <Button key={i} aria-label={`منصة ${i + 1}`} variant="secondary" disabled={paused || left === 0} className={`aspect-square h-auto text-3xl ${i === active ? "bg-mint text-background hover:bg-mint/80" : "bg-muted"}`} onClick={() => {
    if (i !== activeRef.current) return; scoreRef.current++; setScore(scoreRef.current); move();
  }}>{i === active ? <Zap className="size-8" fill="currentColor" /> : <span className="text-muted-foreground/40">·</span>}</Button>)}</div>{paused && <p className="text-center text-sm text-muted-foreground">متوقف مؤقتًا</p>}</div>;
}

const icons = [Star, Gem, Zap];
type Result = { gameId: string; score: number; xp: number; coins: number; best: number };
export function MiniGames() {
  const [active, setActive] = useState<string | null>(null);
  const [paused, setPaused] = useState(false);
  const [result, setResult] = useState<Result | null>(null);
  const [board, setBoard] = useState("g1");
  const completed = useRef(false);
  const game = games.find(g => g.id === active);
  const start = (id: string) => { completed.current = false; setResult(null); setPaused(false); setActive(id); };
  const finish = (score: number) => {
    if (!active || completed.current) return; completed.current = true;
    const reward = roundReward(active, score);
    recordScore(active, getState().profile.name, score); addXp(reward.xp); addCoins(reward.coins);
    setResult({ gameId: active, score, ...reward, best: topScores(active, 1)[0]?.score ?? score }); setBoard(active);
  };
  const back = () => { setActive(null); setResult(null); setPaused(false); };
  if (game) return <div className="space-y-4"><div className="flex items-center justify-between gap-2"><Button variant="ghost" size="icon" title="رجوع للألعاب" aria-label="رجوع للألعاب" onClick={back}><ArrowRight /></Button><h3 className="font-display text-xl">{game.name}</h3>{game.id !== "g2" && !result ? <Button variant="secondary" size="icon" title={paused ? "متابعة" : "إيقاف مؤقت"} aria-label={paused ? "متابعة" : "إيقاف مؤقت"} onClick={() => setPaused(p => !p)}>{paused ? <Play /> : <Pause />}</Button> : <span className="size-9" />}</div>
    {result ? <div className="space-y-5 py-4 text-center"><Trophy className="mx-auto size-12 text-gold" /><h3 className="font-display text-3xl">اكتملت الجولة!</h3><p className="font-display text-5xl text-mint">{result.score}<span className="ms-2 font-sans text-sm text-muted-foreground">نقطة</span></p><p className="text-sm text-muted-foreground">أفضل نتيجة: {result.best}</p><div className="flex justify-center gap-5 text-sm"><span className="text-mint">+{result.xp} XP</span><span className="text-gold">+{result.coins} 🪙</span></div><div className="flex justify-center gap-2"><Button onClick={() => start(result.gameId)}><RotateCcw />العب مجددًا</Button><Button variant="secondary" onClick={back}>الألعاب</Button></div></div> : game.id === "g1" ? <StarRace paused={paused} onDone={finish} /> : game.id === "g2" ? <CrystalQuiz onDone={finish} /> : <PlatformHop paused={paused} onDone={finish} />}
  </div>;
  return <div className="space-y-6"><div className="flex items-center justify-between"><span className="text-xs text-muted-foreground">٣ ألعاب</span><span className="flex items-center gap-1 text-xs text-gold"><Trophy className="size-4" />سجلات هذا الجهاز</span></div><ul className="space-y-2">{games.map((g, i) => { const Icon = icons[i] ?? Star; return <li key={g.id}><Button variant="secondary" className="h-auto min-h-20 w-full justify-start gap-3 whitespace-normal rounded-lg p-3 text-start" onClick={() => start(g.id)}><span className={`grid size-12 shrink-0 place-items-center rounded-lg ${i === 0 ? "bg-gold/15 text-gold" : i === 1 ? "bg-accent/15 text-accent" : "bg-mint/15 text-mint"}`}><Icon className="size-6" /></span><span className="min-w-0 flex-1"><b className="block">{g.name}</b><span className="mt-1 block text-xs font-normal leading-relaxed text-muted-foreground">{g.desc}</span></span><Play className="shrink-0" /></Button></li>; })}</ul><section className="space-y-3 border-t border-border pt-4"><h3 className="flex items-center gap-2 text-sm font-semibold"><Trophy className="size-4 text-gold" />أفضل النتائج</h3><div className="grid grid-cols-3 gap-1">{games.map(g => <Button key={g.id} variant={board === g.id ? "default" : "ghost"} className="h-10 whitespace-normal px-1 text-xs" aria-pressed={board === g.id} onClick={() => setBoard(g.id)}>{g.name}</Button>)}</div>{topScores(board).length ? <ol className="space-y-2">{topScores(board).map((s, i) => <li key={`${s.at}-${i}`} className="flex items-center gap-3 border-b border-border py-2 text-sm"><span className="w-5 text-muted-foreground">{i + 1}</span><span className="flex-1">{s.name}</span><b className="text-gold">{s.score}</b></li>)}</ol> : <p className="py-3 text-center text-sm text-muted-foreground">لا نتائج بعد</p>}</section></div>;
}
