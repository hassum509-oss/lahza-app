import { useEffect, useRef, useState } from "react";
import { WorldView } from "@/components/world/WorldView";
import { isWorldRequest } from "@/lib/world-bridge";

export function LahzaApp() {
  const shell = useRef<HTMLIFrameElement>(null);
  const [inWorld, setInWorld] = useState(false);

  useEffect(() => {
    const receive = (event: MessageEvent) => {
      if (event.origin !== window.location.origin || event.source !== shell.current?.contentWindow) return;
      if (isWorldRequest(event.data)) setInWorld(true);
    };
    window.addEventListener("message", receive);
    return () => window.removeEventListener("message", receive);
  }, []);

  return (
    <main className="fixed inset-0 bg-background" dir="rtl">
      <iframe ref={shell} src="/apps/lahza.html" title="تطبيق لحظة" className="h-full w-full border-0" allow="camera; microphone; fullscreen" tabIndex={inWorld ? -1 : 0} aria-hidden={inWorld} />
      {inWorld && <div className="fixed inset-0 z-50 bg-background"><WorldView onExit={() => { setInWorld(false); shell.current?.focus(); }} /></div>}
    </main>
  );
}