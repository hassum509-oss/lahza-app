import { useEffect, useState, type ReactNode } from "react";
import type { Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import "@lovable.dev/cloud-auth-js/styles.css";

export function useSession() {
  const [session, setSession] = useState<Session | null | undefined>(undefined);
  useEffect(() => {
    const { data } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    return () => data.subscription.unsubscribe();
  }, []);
  return session;
}

export function AuthGate({ children }: { children: ReactNode }) {
  const session = useSession();
  if (session === undefined) return <div className="sky-bg grid min-h-screen place-items-center text-muted-foreground">…</div>;
  if (!session) return <AuthScreen />;
  return <>{children}</>;
}

function AuthScreen() {
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true); setMsg(null);
    if (mode === "in") {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) setMsg("البريد أو كلمة المرور غير صحيحة");
    } else {
      const { error } = await supabase.auth.signUp({ email, password, options: { emailRedirectTo: window.location.origin } });
      setMsg(error ? error.message : "تفقد بريدك لتأكيد الحساب ✉️");
    }
    setBusy(false);
  };
  const oauth = async (p: "google" | "lovable") => {
    const r = await lovable.auth.signInWithOAuth(p, { redirect_uri: window.location.origin });
    if (r.error) setMsg("تعذر تسجيل الدخول، حاول مجدداً");
  };

  return (
    <div dir="rtl" className="sky-bg grid min-h-screen place-items-center p-4">
      <div className="glass w-full max-w-sm space-y-4 rounded-3xl p-6">
        <div className="text-center">
          <h1 className="font-display text-5xl">لحظة</h1>
          <p className="text-xs tracking-[0.3em] text-muted-foreground">LAHZA SOCIAL</p>
        </div>
        <button type="button" className="lovable-auth-button w-full" onClick={() => oauth("lovable")}>Continue with Lovable</button>
        <button type="button" onClick={() => oauth("google")} className="min-h-11 w-full rounded-full bg-muted text-sm">المتابعة عبر Google</button>
        <div className="text-center text-xs text-muted-foreground">أو بالبريد الإلكتروني</div>
        <form onSubmit={submit} className="space-y-2">
          <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="البريد الإلكتروني" className="min-h-11 w-full rounded-full bg-muted px-4 text-sm outline-none focus:ring-2 focus:ring-ring" />
          <input type="password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="كلمة المرور" className="min-h-11 w-full rounded-full bg-muted px-4 text-sm outline-none focus:ring-2 focus:ring-ring" />
          <button disabled={busy} className="neon-bg min-h-11 w-full rounded-full text-sm text-primary-foreground disabled:opacity-50">{mode === "in" ? "تسجيل الدخول" : "إنشاء حساب"}</button>
        </form>
        {msg && <p className="text-center text-sm text-muted-foreground">{msg}</p>}
        <button type="button" className="w-full text-center text-xs text-muted-foreground underline" onClick={() => setMode(mode === "in" ? "up" : "in")}>
          {mode === "in" ? "ليس لديك حساب؟ أنشئ حساباً" : "لديك حساب؟ سجّل الدخول"}
        </button>
      </div>
    </div>
  );
}
