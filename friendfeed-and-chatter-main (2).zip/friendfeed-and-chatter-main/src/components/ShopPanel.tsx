// Shop + inventory + wallet. Demo currency only — no real payments.
import { useState } from "react";
import { useGame, setState, showToast, addXp, refreshInventory } from "@/lib/game-store";
import { grantItem, recordTx } from "@/lib/profile-store";
import { shopItems, RARITY_LABELS, type Rarity } from "@/services/mock-data";

const RARITY_STYLE: Record<Rarity, string> = {
  common: "border-border",
  rare: "border-accent shadow-[0_0_12px_oklch(0.78_0.16_320/40%)]",
  legendary: "border-gold shadow-[0_0_16px_oklch(0.84_0.15_85/45%)]",
};

export function ShopPanel() {
  const profile = useGame((s) => s.profile);
  const inventory = useGame((s) => s.inventory);
  const owned = new Set(inventory.map((i) => i.itemId));
  const buy = (id: string, name: string, price: number) => {
    if (profile.coins < price) { showToast("الرصيد غير كافٍ — اشحن من المحفظة"); return; }
    setState((s) => ({ profile: { ...s.profile, coins: s.profile.coins - price }, missions: s.missions.map((m) => m.id === "m2" ? { ...m, progress: 1 } : m) }));
    grantItem(id);
    recordTx("purchase", name, -price);
    refreshInventory();
    showToast(`اشتريت ${name}!`);
    addXp(15);
  };
  return (
    <div className="space-y-3">
      <p className="text-xs text-muted-foreground">عملات تجريبية فقط — لا معاملات حقيقية. رصيدك: <b className="text-gold">🪙 {profile.coins}</b></p>
      <ul className="grid grid-cols-2 gap-2">
        {shopItems.map((it) => (
          <li key={it.id} className={`rounded-xl border-2 bg-muted p-3 text-center ${RARITY_STYLE[it.rarity]}`}>
            <p className="text-3xl">{it.emoji}</p>
            <p className="mt-1 text-sm font-semibold">{it.name}</p>
            <p className={`text-[10px] ${it.rarity === "legendary" ? "text-gold" : it.rarity === "rare" ? "text-accent" : "text-muted-foreground"}`}>{RARITY_LABELS[it.rarity]}</p>
            {owned.has(it.id) ? (
              <p className="mt-2 text-xs text-mint">✓ تملكه</p>
            ) : (
              <button className="neon-bg mt-2 min-h-9 w-full rounded-full text-xs text-primary-foreground" onClick={() => buy(it.id, it.name, it.price)}>🪙 {it.price}</button>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

export function InventoryPanel() {
  const inventory = useGame((s) => s.inventory);
  const items = inventory.map((inv) => shopItems.find((s) => s.id === inv.itemId)).filter(Boolean);
  if (items.length === 0) return <p className="py-6 text-center text-sm text-muted-foreground">جردك فارغ — زر المتجر لاقتناء أول عنصر ✨</p>;
  return (
    <ul className="grid grid-cols-3 gap-2">
      {items.map((it) => (
        <li key={it!.id} className={`rounded-xl border-2 bg-muted p-3 text-center ${RARITY_STYLE[it!.rarity]}`}>
          <p className="text-2xl">{it!.emoji}</p>
          <p className="mt-1 text-xs">{it!.name}</p>
        </li>
      ))}
    </ul>
  );
}

const TOPUP_PACKS = [
  { id: "p1", coins: 500, label: "حزمة صغيرة" },
  { id: "p2", coins: 1500, label: "حزمة متوسطة" },
  { id: "p3", coins: 5000, label: "حزمة كبيرة" },
];

export function WalletPanel() {
  const profile = useGame((s) => s.profile);
  const tx = useGame((s) => s.tx);
  const [busy, setBusy] = useState(false);
  const topup = (coins: number, label: string) => {
    setBusy(true);
    // Simulated demo top-up — NOT a real payment. No provider, no card, no charge.
    setTimeout(() => {
      setState((s) => ({ profile: { ...s.profile, coins: s.profile.coins + coins } }));
      recordTx("topup", `${label} (تجريبي)`, coins);
      refreshInventory();
      showToast(`أُضيفت ${coins} عملة تجريبية`);
      setBusy(false);
    }, 600);
  };
  return (
    <div className="space-y-4">
      <div className="glass flex items-center justify-between rounded-2xl p-4">
        <div><p className="text-xs text-muted-foreground">الرصيد التجريبي</p><p className="font-display text-3xl text-gold">🪙 {profile.coins}</p></div>
        <div><p className="text-xs text-muted-foreground">جواهر</p><p className="font-display text-3xl text-mint">💎 {profile.gems}</p></div>
      </div>
      <div className="rounded-xl border border-border bg-muted/50 p-3 text-xs text-muted-foreground">
        ⚠️ الشحن هنا محاكاة تجريبية فقط. لا يوجد دفع حقيقي ولا يتم خصم أي مبلغ. الدفع الفعلي يتطلب ربط مزود دفع ومصادقة وخادم آمن لاحقاً.
      </div>
      <div className="grid grid-cols-3 gap-2">
        {TOPUP_PACKS.map((p) => (
          <button key={p.id} disabled={busy} onClick={() => topup(p.coins, p.label)} className="neon-bg min-h-14 rounded-xl text-sm font-semibold text-primary-foreground disabled:opacity-50">
            +{p.coins} 🪙<span className="block text-[10px] font-normal">{p.label}</span>
          </button>
        ))}
      </div>
      <section>
        <h3 className="mb-2 text-sm font-semibold">سجل العمليات</h3>
        {tx.length === 0 ? <p className="text-xs text-muted-foreground">لا عمليات بعد.</p> : (
          <ul className="max-h-40 space-y-1 overflow-y-auto text-xs">
            {tx.map((t) => (
              <li key={t.id} className="flex justify-between rounded-lg bg-muted px-3 py-2">
                <span>{t.label}</span>
                <b className={t.amount >= 0 ? "text-mint" : "text-destructive"}>{t.amount >= 0 ? "+" : ""}{t.amount} 🪙</b>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
