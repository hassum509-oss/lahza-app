// Local social data (posts + direct messages), persisted in localStorage.
import { useSyncExternalStore } from "react";

export interface Post { id: string; author: string; handle: string; text: string; time: number; likes: number; liked?: boolean; comments: { id: string; author: string; text: string }[] }
export interface DM { id: string; from: "me" | "them"; text: string; time: number }
export interface Conversation { id: string; name: string; online: boolean; messages: DM[]; unread: number }

const now = Date.now();
const seedPosts: Post[] = [
  { id: "p1", author: "ليان", handle: "@layan", text: "الساحة الليلة رهيبة 🌙✨ مين موجود عند البلورة؟", time: now - 1000 * 60 * 12, likes: 24, comments: [{ id: "k1", author: "سالم", text: "جاي حالاً!" }] },
  { id: "p2", author: "سالم", handle: "@salem", text: "كسرت رقمي في سباق النجوم: 31 نجمة ⭐ تحدوني!", time: now - 1000 * 60 * 60 * 2, likes: 57, comments: [] },
  { id: "p3", author: "ريم", handle: "@reem", text: "بنيت عالمي الأول «واحة الهدوء» 🌿 زوروه وقولوا رأيكم", time: now - 1000 * 60 * 60 * 9, likes: 103, comments: [] },
];
const seedConvos: Conversation[] = [
  { id: "f1", name: "ليان", online: true, unread: 2, messages: [{ id: "a", from: "them", text: "مساء النور! 🌙", time: now - 600000 }, { id: "b", from: "them", text: "تعال الساحة نلعب", time: now - 300000 }] },
  { id: "f2", name: "سالم", online: true, unread: 0, messages: [{ id: "c", from: "me", text: "كم نجمة جمعت؟", time: now - 7200000 }, { id: "d", from: "them", text: "31 😎", time: now - 7100000 }] },
  { id: "f3", name: "ريم", online: false, unread: 1, messages: [{ id: "e", from: "them", text: "شفت عالمي الجديد؟", time: now - 30000000 }] },
  { id: "f4", name: "خالد", online: false, unread: 0, messages: [] },
];

const KEY = "lahza.social.v1";
interface SocialState { posts: Post[]; convos: Conversation[] }
let state: SocialState = { posts: seedPosts, convos: seedConvos };
let loaded = false;
const listeners = new Set<() => void>();

function ensureLoaded() {
  if (loaded || typeof window === "undefined") return;
  loaded = true;
  try { const raw = localStorage.getItem(KEY); if (raw) state = { ...state, ...JSON.parse(raw) }; } catch { /* ignore */ }
}
function set(patch: (s: SocialState) => Partial<SocialState>) {
  ensureLoaded();
  state = { ...state, ...patch(state) };
  try { localStorage.setItem(KEY, JSON.stringify(state)); } catch { /* ignore */ }
  listeners.forEach((l) => l());
}
export function useSocial<T>(sel: (s: SocialState) => T): T {
  return useSyncExternalStore(
    (l) => { ensureLoaded(); listeners.add(l); l(); return () => listeners.delete(l); },
    () => sel(state),
    () => sel({ posts: seedPosts, convos: seedConvos }),
  );
}

const uid = () => Math.random().toString(36).slice(2, 9);

export function createPost(author: string, handle: string, text: string) {
  set((s) => ({ posts: [{ id: uid(), author, handle, text, time: Date.now(), likes: 0, comments: [] }, ...s.posts] }));
}
export function toggleLike(id: string) {
  set((s) => ({ posts: s.posts.map((p) => p.id === id ? { ...p, liked: !p.liked, likes: p.likes + (p.liked ? -1 : 1) } : p) }));
}
export function addComment(id: string, author: string, text: string) {
  set((s) => ({ posts: s.posts.map((p) => p.id === id ? { ...p, comments: [...p.comments, { id: uid(), author, text }] } : p) }));
}
export function deletePost(id: string) {
  set((s) => ({ posts: s.posts.filter((p) => p.id !== id) }));
}

const replies = ["😂😂", "تمام! نلتقي بالساحة", "حلو والله ✨", "ثواني وأرد عليك", "👍"];
export function sendDM(convoId: string, text: string) {
  set((s) => ({ convos: s.convos.map((c) => c.id === convoId ? { ...c, messages: [...c.messages, { id: uid(), from: "me", text, time: Date.now() }] } : c) }));
  const c = state.convos.find((x) => x.id === convoId);
  if (c?.online) {
    setTimeout(() => set((s) => ({ convos: s.convos.map((x) => x.id === convoId ? { ...x, messages: [...x.messages, { id: uid(), from: "them", text: replies[Math.floor(Math.random() * replies.length)] ?? "👍", time: Date.now() }] } : x) })), 1400);
  }
}
export function markRead(convoId: string) {
  set((s) => ({ convos: s.convos.map((c) => c.id === convoId ? { ...c, unread: 0 } : c) }));
}

export function timeAgo(t: number) {
  const m = Math.floor((Date.now() - t) / 60000);
  if (m < 1) return "الآن";
  if (m < 60) return `منذ ${m} د`;
  const h = Math.floor(m / 60);
  if (h < 24) return `منذ ${h} س`;
  return `منذ ${Math.floor(h / 24)} يوم`;
}
