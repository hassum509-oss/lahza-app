import { describe, expect, it } from "vitest";
import { nextPlatform, roundReward, ROUND_SECONDS } from "./mini-game-rules";

describe("Mini-game rounds", () => {
  it("keeps the star race at 30 seconds", () => { expect(ROUND_SECONDS.g1).toBe(30); });
  it("keeps platform rounds at 20 seconds", () => { expect(ROUND_SECONDS.g3).toBe(20); });
  it("calculates the full star reward", () => { expect(roundReward("g1", 15)).toEqual({ xp: 45, coins: 80 }); });
  it("calculates the full quiz reward", () => { expect(roundReward("g2", 5)).toEqual({ xp: 45, coins: 70 }); });
  it("caps score XP bonuses at 30", () => { expect(roundReward("g3", 40)).toEqual({ xp: 55, coins: 120 }); });
  it("always moves to a different valid platform", () => {
    for (let current = 0; current < 9; current++) for (const random of [0, 0.25, 0.5, 0.999, 1]) {
      const next = nextPlatform(current, random);
      expect(next).not.toBe(current); expect(next).toBeGreaterThanOrEqual(0); expect(next).toBeLessThan(9);
    }
  });
});