export const OPEN_WORLD_MESSAGE = "lahza:open-world";

export function isWorldRequest(data: unknown): boolean {
  return typeof data === "object" && data !== null &&
    "type" in data && data.type === OPEN_WORLD_MESSAGE;
}