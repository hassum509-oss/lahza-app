import { useSyncExternalStore } from "react";
import { mockProfile, mockFriends, mockMissions, mockChat, type ChatMsg } from "@/services/mock-data";
import { loadInventory, loadTx, type InventoryItem, type TxRecord } from "@/lib/profile-store";

export type Quality = "low" | "medium" | "high" | "ultra";

export interface GameState {
  profile: typeof mockProfile;
  friends: typeof mockFriends;
  missions: typeof mockMissions;
  chat: ChatMsg[];
  quality: Quality;
  nearby: string | null; // id of nearby NPC or location
  toast: string | null;
  panel: null | "shop" | "games" | "friends" | "chat" | "missions" | "settings" | "notifications" | "inventory" | "wallet";
  inventory: InventoryItem[];
  tx: TxRecord[];
}

const PROFILE_KEY = "lahza.profile.v1";
const QUALITY_KEY = "lahza.quality.v1";

function loadProfile(): typeof mockProfile {
  try {
    const raw = localStorage.getItem(PROFILE_KEY);
    if (raw) return { ...mockProfile, ...JSON.parse(raw) };
  } catch { /* ignore */ }
  return mockProfile;
}
function loadQuality(): Quality {
  try {
    const q = localStorage.getItem(QUALITY_KEY);
    if (q === "low" || q === "medium" || q === "high" || q === "ultra") return q;
  } catch { /* ignore */ }
  // Auto: mobile/touch devices default to medium
  if (typeof window !== "undefined" && (window.innerWidth < 900 || "ontouchstart" in window)) return "medium";
  return "high";
}

let state: GameState = {
  profile: loadProfile(),
  friends: mockFriends,
  missions: mockMissions,
  chat: mockChat,
  quality: loadQuality(),
  nearby: null,
  toast: null,
  panel: null,
  inventory: typeof window !== "undefined" ? loadInventory() : [],
  tx: typeof window !== "undefined" ? loadTx() : [],
};
const listeners = new Set<() => void>();

export function getState() { return state; }
export function setState(p: Partial<GameState> | ((s: GameState) => Partial<GameState>)) {
  const patch = typeof p === "function" ? p(state) : p;
  state = { ...state, ...patch };
  if (patch.profile) {
    try { localStorage.setItem(PROFILE_KEY, JSON.stringify(patch.profile)); } catch { /* ignore */ }
  }
  if (patch.quality) {
    try { localStorage.setItem(QUALITY_KEY, patch.quality); } catch { /* ignore */ }
  }
  listeners.forEach((l) => l());
}
export function useGame<T>(sel: (s: GameState) => T): T {
  return useSyncExternalStore(
    (l) => { listeners.add(l); return () => listeners.delete(l); },
    () => sel(state),
    () => sel(state),
  );
}

let toastTimer: ReturnType<typeof setTimeout> | undefined;
export function showToast(msg: string) {
  setState({ toast: msg });
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => setState({ toast: null }), 2600);
}

export function addXp(amount: number) {
  setState((s) => {
    let { xp, level } = s.profile;
    xp += amount;
    const need = level * 100;
    if (xp >= need) { xp -= need; level += 1; }
    return { profile: { ...s.profile, xp, level } };
  });
}

export function addCoins(amount: number) {
  setState((s) => ({ profile: { ...s.profile, coins: s.profile.coins + amount } }));
}

export function refreshInventory() {
  setState({ inventory: loadInventory(), tx: loadTx() });
}

/** Mutable per-frame input — read inside useFrame, never triggers React renders. */
export const input = { x: 0, y: 0, run: false, jump: false, emote: false, camYaw: 0 };
