// Persistent player data: inventory, wallet transactions, leaderboard, game scores.
// All local (localStorage) — no real payments or multiplayer.

export interface InventoryItem {
  itemId: string;
  ownedAt: number;
}

export interface TxRecord {
  id: string;
  kind: "purchase" | "topup" | "reward";
  label: string;
  amount: number; // +credit / -debit in coins
  at: number;
}

export interface ScoreEntry {
  name: string;
  game: string;
  score: number;
  at: number;
}

const INV_KEY = "lahza.inventory.v1";
const TX_KEY = "lahza.tx.v1";
const SCORE_KEY = "lahza.scores.v1";

function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}
function write(key: string, v: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(v));
  } catch {
    /* ignore */
  }
}

export const loadInventory = (): InventoryItem[] => read(INV_KEY, []);
export const ownsItem = (itemId: string) => loadInventory().some((i) => i.itemId === itemId);
export function grantItem(itemId: string) {
  const inv = loadInventory();
  if (!inv.some((i) => i.itemId === itemId)) {
    inv.push({ itemId, ownedAt: Date.now() });
    write(INV_KEY, inv);
  }
}

export const loadTx = (): TxRecord[] => read(TX_KEY, []);
export function recordTx(kind: TxRecord["kind"], label: string, amount: number) {
  const tx = loadTx();
  tx.unshift({ id: `t_${Date.now().toString(36)}`, kind, label, amount, at: Date.now() });
  write(TX_KEY, tx.slice(0, 50));
}

export const loadScores = (): ScoreEntry[] => read(SCORE_KEY, []);
export function recordScore(game: string, name: string, score: number) {
  const s = loadScores();
  s.push({ game, name, score, at: Date.now() });
  write(SCORE_KEY, s);
}
export function topScores(game: string, n = 5): ScoreEntry[] {
  return loadScores()
    .filter((s) => s.game === game)
    .sort((a, b) => b.score - a.score)
    .slice(0, n);
}
