// User-created worlds: config model, templates, localStorage persistence.
// Local-only ownership — no real multi-user publishing without a backend.

export type WorldTemplate = "nature" | "city" | "space" | "fantasy" | "beach";
export type TimeOfDay = "sunrise" | "morning" | "sunset" | "night";
export type WorldSize = "small" | "medium" | "large";

export interface WorldConfig {
  id: string;
  name: string;
  description: string;
  creator: string;
  template: WorldTemplate;
  size: WorldSize;
  /** 0..1 density multipliers */
  trees: number;
  rocks: number;
  lake: boolean;
  buildings: number;
  lighting: number; // lamp count 0..1
  music: "calm" | "energetic" | "mystic" | "none";
  weather: { rain: boolean; fog: boolean; wind: boolean };
  timeOfDay: TimeOfDay;
  dayCycle: boolean;
  published: boolean;
  visits: number;
  createdAt: number;
  updatedAt: number;
}

export const TEMPLATES: Record<WorldTemplate, { label: string; emoji: string; desc: string }> = {
  nature: { label: "طبيعة", emoji: "🌿", desc: "غابات وأشجار وبحيرات هادئة" },
  city: { label: "مدينة", emoji: "🏙️", desc: "مبانٍ ونيون وأضواء" },
  space: { label: "فضاء", emoji: "🪐", desc: "نجوم وكويكبات وسديم" },
  fantasy: { label: "خيال", emoji: "🔮", desc: "بلورات وسحر وضباب" },
  beach: { label: "شاطئ", emoji: "🏖️", desc: "رمال ومياه وغروب" },
};

export const TIME_LABELS: Record<TimeOfDay, string> = { sunrise: "شروق", morning: "صباح", sunset: "غروب", night: "ليل" };
export const SIZE_RADIUS: Record<WorldSize, number> = { small: 24, medium: 36, large: 52 };

const KEY = "lahza.worlds.v1";

export function defaultWorld(creator: string): WorldConfig {
  return {
    id: `w_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`,
    name: "عالمي الجديد",
    description: "",
    creator,
    template: "nature",
    size: "medium",
    trees: 0.6,
    rocks: 0.4,
    lake: true,
    buildings: 0.3,
    lighting: 0.6,
    music: "calm",
    weather: { rain: false, fog: false, wind: false },
    timeOfDay: "sunset",
    dayCycle: false,
    published: false,
    visits: 0,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
}

export function loadWorlds(): WorldConfig[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const arr = JSON.parse(raw) as WorldConfig[];
    return Array.isArray(arr) ? arr : [];
  } catch {
    return [];
  }
}

export function saveWorlds(worlds: WorldConfig[]) {
  try {
    localStorage.setItem(KEY, JSON.stringify(worlds));
  } catch {
    /* storage full/blocked */
  }
}

export function upsertWorld(w: WorldConfig) {
  const all = loadWorlds();
  const i = all.findIndex((x) => x.id === w.id);
  const next = { ...w, updatedAt: Date.now() };
  if (i >= 0) all[i] = next;
  else all.push(next);
  saveWorlds(all);
  return next;
}

export function deleteWorld(id: string) {
  saveWorlds(loadWorlds().filter((w) => w.id !== id));
}

export function getWorld(id: string): WorldConfig | null {
  return loadWorlds().find((w) => w.id === id) ?? null;
}

/** Curated sample worlds shown in the gallery (read-only, clearly marked as samples). */
export const FEATURED_WORLDS: WorldConfig[] = [
  { ...defaultWorld("فريق لحظة"), id: "feat_crystal", name: "ساحة البلورة", description: "الساحة الرئيسية: بلورة مضيئة ونيون بنفسجي.", template: "fantasy", timeOfDay: "night", weather: { rain: false, fog: true, wind: false }, visits: 1284, published: true },
  { ...defaultWorld("فريق لحظة"), id: "feat_oasis", name: "واحة الفجر", description: "بحيرة هادئة وأشجار عند الشروق.", template: "nature", timeOfDay: "sunrise", lake: true, trees: 0.9, visits: 862, published: true },
  { ...defaultWorld("فريق لحظة"), id: "feat_neon", name: "حي النيون", description: "مدينة ليلية صاخبة بالأضواء.", template: "city", timeOfDay: "night", buildings: 0.9, trees: 0.1, visits: 647, published: true },
  { ...defaultWorld("فريق لحظة"), id: "feat_orbit", name: "مدار النجوم", description: "عالم فضائي تحت سماء مرصّعة.", template: "space", timeOfDay: "night", weather: { rain: false, fog: false, wind: true }, visits: 431, published: true },
  { ...defaultWorld("فريق لحظة"), id: "feat_beach", name: "شاطئ الغروب", description: "رمال ذهبية وأمواج عند الغروب.", template: "beach", timeOfDay: "sunset", lake: true, visits: 355, published: true },
];
