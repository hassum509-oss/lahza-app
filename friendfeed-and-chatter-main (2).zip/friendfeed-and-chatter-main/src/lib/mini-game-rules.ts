export const ROUND_SECONDS = { g1: 30, g3: 20 };
export const QUIZ = [
  { q: "كم عدد أيام الأسبوع؟", a: ["7", "5", "6"], c: 0 },
  { q: "ما أكبر كوكب في المجموعة الشمسية؟", a: ["المريخ", "المشتري", "الأرض"], c: 1 },
  { q: "كم دقيقة في الساعة؟", a: ["100", "90", "60"], c: 2 },
  { q: "ما لون السماء الصافية؟", a: ["أزرق", "أخضر", "أحمر"], c: 0 },
  { q: "كم عدد قارات العالم؟", a: ["5", "7", "9"], c: 1 },
];

export function roundReward(gameId: string, score: number) {
  const bases = gameId === "g1" ? [30, 50] : gameId === "g2" ? [40, 60] : [25, 40];
  const points = Math.max(0, Math.floor(score));
  return { xp: (bases[0] ?? 0) + Math.min(points, 30), coins: (bases[1] ?? 0) + points * 2 };
}

export function nextPlatform(current: number, random = Math.random()) {
  return (current + 1 + Math.floor(Math.min(Math.max(random, 0), 0.999999) * 8)) % 9;
}