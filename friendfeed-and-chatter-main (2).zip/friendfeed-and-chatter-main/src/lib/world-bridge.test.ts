import { describe, expect, it } from "vitest";
import { isWorldRequest } from "./world-bridge";

describe("Uploaded app world requests", () => {
  it("accepts the uploaded app's explicit world entry request", () => {
    expect(isWorldRequest({ type: "lahza:open-world" })).toBe(true);
  });
  it("rejects unrelated or malformed messages", () => {
    for (const data of [null, "lahza:open-world", {}, { type: "other" }]) {
      expect(isWorldRequest(data)).toBe(false);
    }
  });
});