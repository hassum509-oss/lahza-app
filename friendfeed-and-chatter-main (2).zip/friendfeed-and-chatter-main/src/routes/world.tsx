import { createFileRoute } from "@tanstack/react-router";
import { WorldView } from "@/components/world/WorldView";

export const Route = createFileRoute("/world")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "عالمي — لحظة | LAHZA SOCIAL" },
      { name: "description", content: "تجوّل في ساحة لحظة الافتراضية: البلورة المضيئة، المتجر، الألعاب وبوابة الأصدقاء." },
      { property: "og:title", content: "عالمي — لحظة" },
      { property: "og:description", content: "ساحة مدينة ليلية تفاعلية ثلاثية الأبعاد." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => <WorldView />,
});
