import { createFileRoute } from "@tanstack/react-router";
import { LahzaApp } from "@/components/LahzaApp";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "لحظة | LAHZA SOCIAL — الرئيسية" },
      { name: "description", content: "لحظة: تطبيق اجتماعي عربي — منشورات، مراسلة، وعوالم افتراضية مع أصدقائك." },
      { property: "og:title", content: "لحظة | LAHZA SOCIAL" },
      { property: "og:description", content: "انشر، راسل أصدقاءك، وادخل عالمك الافتراضي." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  ssr: false,
  component: LahzaApp,
});
