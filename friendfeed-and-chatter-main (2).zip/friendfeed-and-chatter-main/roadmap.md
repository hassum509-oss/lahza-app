# Roadmap
- [x] Main social screen on open (feed, posting, messages, worlds, profile)
- [x] Enable Lovable Cloud + sign-in (email, Google, Lovable)
- [x] Enable file storage (media bucket)
- [ ] Integrate the existing world into the uploaded Lahza application
- [ ] Verify entering the world and returning to the uploaded application
- [ ] Make all three world games playable with results, replay, and local records
- [ ] Verify game rounds and return to the world
